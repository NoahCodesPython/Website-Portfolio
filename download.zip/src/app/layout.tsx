
import type { Metadata } from 'next';
import { Geist, Geist_Mono } from 'next/font/google';
import './globals.css';
import { ThemeProvider } from '@/components/theme-provider';
import Header from '@/components/layout/header';
import { Toaster } from '@/components/ui/toaster';
import BackgroundParticles from '@/components/background-particles';

const geistSans = Geist({
  variable: '--font-geist-sans',
  subsets: ['latin'],
});

const geistMono = Geist_Mono({
  variable: '--font-geist-mono',
  subsets: ['latin'],
});

export const metadata: Metadata = {
  title: 'Charan - Portfolio',
  description: 'A modern portfolio website built with Next.js and AI.',
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="en" suppressHydrationWarning>
      <body className={`${geistSans.variable} ${geistMono.variable} antialiased text-foreground bg-background`} suppressHydrationWarning>
        <ThemeProvider defaultTheme="system" storageKey="charan-portfolio-theme">
          <BackgroundParticles />
          <Header />
          <main className="pt-16 relative z-10"> {/* Add padding-top to offset fixed header */}
            {children}
          </main>
          <Toaster />
        </ThemeProvider>
      </body>
    </html>
  );
}
