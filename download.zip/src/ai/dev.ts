import { config } from 'dotenv';
config();

import '@/ai/flows/generate-intro.ts';
import '@/ai/flows/generate-project-image.ts';
